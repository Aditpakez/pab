import 'package:flutter/material.dart';

import '../models/candi.dart';

class NamaWidget extends StatefulWidget {
  // todo1 buat variable
  final Candi candi;
  const NamaWidget({super.key, required this.candi});

  @override
  State<NamaWidget> createState() => _NamaWidgetState();
}

class _NamaWidgetState extends State<NamaWidget> {
  @override
  Widget build(BuildContext context) {
    return Card(
      // todo 2 set parameter shape, margin, dan elevation
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      margin: EdgeInsets.all(4),
      elevation: 1,

      child: Column(
        children: [
          // todo 3 : image widget
          Image.asset(
            widget.candi.imageassets,
            width: double.infinity,
            fit: BoxFit.cover,
          ),

          // todo 4 text widget (nama candi)
          Text(widget.candi.name),

          // todo 5 text widget (type candi)
          Text(widget.candi.type),
        ],
      ),
    );
  }
}