import 'package:flutter/material.dart';

import '../data/candi_data.dart';

class NamaWidget extends StatefulWidget {
  const NamaWidget({super.key});

  @override
  State<NamaWidget> createState() => _NamaWidgetState();
}

class _NamaWidgetState extends State<NamaWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Wisata Candi"),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
        ),
        padding: EdgeInsets.all(8),
        itemCount: candiList.length,
        itemBuilder: (context, index) {
          Candi candi = candiList[index];
          return Text(candi.name);
        },
      ),
    );
  }
}